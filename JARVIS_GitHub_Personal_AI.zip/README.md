# J.A.R.V.I.S. Personal AI — GitHub Pages Edition

A mobile-first JARVIS-style progressive web app (PWA). The front end can be hosted on **GitHub Pages for free**. It includes a HUD dashboard, animated reactor, voice input/output where supported, local notes/memory, quick website actions, focus mode, install-to-home-screen support, and optional AI connection.

## Important reality check

A website/PWA cannot replace Android's real system UI, lock screen, default assistant, or freely control installed apps and phone settings. It can look and behave like a full-screen personal interface when installed. Deeper device integration requires a native Android app and explicit Android permissions.

## 1. Publish the front end on GitHub Pages

1. Create/sign in to a GitHub account at https://github.com.
2. Create a new **public** repository, for example `jarvis-personal-ai`.
3. Upload the contents of this project (upload `index.html`, `style.css`, `app.js`, `manifest.webmanifest`, `sw.js`, `assets/`, and `cloudflare-worker/` to the repository root as shown; do not upload the ZIP itself as the only file).
4. Open repository **Settings → Pages**.
5. Under build and deployment, select **Deploy from a branch**, choose `main` and `/ (root)`, then Save.
6. Wait for GitHub Pages to publish. Your site URL will look like `https://YOUR-USERNAME.github.io/jarvis-personal-ai/`.

GitHub Pages is static hosting and does not run `cloudflare-worker/worker.js`.

## 2. Optional: enable AI chat with a separate free-tier backend

The front end deliberately does **not** contain an API key. To enable AI chat, deploy the Worker in `cloudflare-worker/` to Cloudflare Workers and store your provider key as a secret.

1. Create an account at https://dash.cloudflare.com/ and open **Workers & Pages**.
2. Create a Worker and paste the contents of `cloudflare-worker/worker.js`, or deploy using Wrangler from the `cloudflare-worker` folder.
3. In Worker settings, add a **secret** named `GEMINI_API_KEY`. Get a key from https://aistudio.google.com/app/apikey. Check provider terms, model availability, rate limits and current free-tier rules in your region.
4. Optional but recommended: set `ALLOWED_ORIGIN` to your exact GitHub Pages origin, e.g. `https://YOUR-USERNAME.github.io`. Do not include the repository path in the origin.
5. Confirm the Worker endpoint responds at `https://YOUR-WORKER.workers.dev/chat`.
6. Open JARVIS → System Settings → AI endpoint, enter that `/chat` URL, then save and test.

The Worker uses Gemini's `gemini-2.5-flash` endpoint; if the provider changes model availability, update the model in `worker.js`. Free tiers and limits can change. Do not commit secrets to GitHub.

## 3. Install on Android

1. Open the published GitHub Pages URL in Chrome.
2. Use the browser menu and select **Install app** or **Add to Home screen**.
3. Launch JARVIS from the new icon. For microphone use, grant permission when asked.

PWA install prompts and speech recognition vary by browser. Battery status is only shown if the browser exposes the Battery Status API.

## Privacy

- Notes and settings are stored in this browser's local storage on this device.
- Saved notes are not automatically sent to the AI backend.
- Messages sent to the AI endpoint are processed by the configured AI provider.
- Avoid saving sensitive information in local notes if other people can access this device.
- Clear memories in **Memory Vault → Clear All**.
- Never place API keys in `app.js`, HTML, or any public repository.

## Current limits

This project has not been deployed to your GitHub or connected to your phone automatically. You must create the repository and configure the optional backend yourself. This is a web/PWA project, not an Android system UI replacement or native APK.
