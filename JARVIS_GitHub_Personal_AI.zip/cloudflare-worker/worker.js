// Cloudflare Worker backend for the JARVIS GitHub Pages frontend.
// Set GEMINI_API_KEY as a Worker secret. Never place it in frontend files.
export default {
  async fetch(request, env) {
    const cors = {
      "Access-Control-Allow-Origin": env.ALLOWED_ORIGIN || "*",
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
      "Content-Type": "application/json"
    };
    if (request.method === "OPTIONS") return new Response(null, { headers: cors });
    if (new URL(request.url).pathname !== "/chat") return new Response(JSON.stringify({ error: "Use POST /chat" }), { status: 404, headers: cors });
    if (request.method !== "POST") return new Response(JSON.stringify({ error: "POST required" }), { status: 405, headers: cors });
    if (!env.GEMINI_API_KEY) return new Response(JSON.stringify({ error: "GEMINI_API_KEY secret is not configured" }), { status: 500, headers: cors });
    try {
      const body = await request.json();
      const message = String(body.message || "").slice(0, 8000);
      if (!message.trim()) return new Response(JSON.stringify({ error: "Message required" }), { status: 400, headers: cors });
      const upstream = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${env.GEMINI_API_KEY}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          systemInstruction: { parts: [{ text: "You are JARVIS, a helpful, concise personal AI assistant inspired by a futuristic sci-fi interface. Be honest about limitations. You cannot directly control the user's Android settings, apps, or hardware unless a specific authorized integration is available. Do not claim to have taken actions you did not take." }] },
          contents: [{ role: "user", parts: [{ text: message }] }],
          generationConfig: { temperature: 0.7, maxOutputTokens: 700 }
        })
      });
      const data = await upstream.json();
      if (!upstream.ok) return new Response(JSON.stringify({ error: data.error?.message || "AI provider request failed" }), { status: upstream.status, headers: cors });
      const reply = data.candidates?.[0]?.content?.parts?.map(p => p.text || "").join("").trim() || "I couldn't form a reply.";
      return new Response(JSON.stringify({ reply }), { headers: cors });
    } catch (error) {
      return new Response(JSON.stringify({ error: "Invalid request or backend error", detail: String(error) }), { status: 400, headers: cors });
    }
  }
};