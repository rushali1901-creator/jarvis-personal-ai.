const $ = (id) => document.getElementById(id);
const KEYS = {notes:'jarvis.notes.v1', settings:'jarvis.settings.v1'};
const defaults = {speak:true,voice:true,reducedMotion:false,endpoint:''};
let settings = {...defaults, ...safeParse(localStorage.getItem(KEYS.settings), {})};
let recognition = null, listening = false, deferredInstall = null, toastTimer = null;
function safeParse(raw, fallback){try{return raw?JSON.parse(raw):fallback}catch{return fallback}}
function getNotes(){return safeParse(localStorage.getItem(KEYS.notes),[])}
function saveNotes(notes){localStorage.setItem(KEYS.notes,JSON.stringify(notes));renderNotes();updateCounts()}
function updateClock(){
 const d=new Date(); $('clock').textContent=d.toLocaleTimeString([], {hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:false});
 $('timeStat').textContent=d.toLocaleTimeString([], {hour:'2-digit',minute:'2-digit',hour12:false});
 $('dateLine').textContent=d.toLocaleDateString([], {weekday:'long',year:'numeric',month:'long',day:'numeric'}).toUpperCase();
 $('tzStat').textContent=Intl.DateTimeFormat().resolvedOptions().timeZone||'DEVICE CLOCK';
 const h=d.getHours();$('greeting').textContent=h<12?'morning':h<18?'afternoon':'evening';
}
function toast(msg){const t=$('toast');t.textContent=msg;t.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>t.classList.remove('show'),2600)}
function updateCounts(){$('memoryCount').textContent=`${getNotes().length} ITEMS`}
function renderNotes(){
 const list=$('notesList'),notes=getNotes();list.innerHTML='';
 if(!notes.length){list.innerHTML='<p class="muted">Your vault is empty. Save a note above, or tell JARVIS: “remember that …”</p>';return}
 notes.slice().reverse().forEach((n,reverseIndex)=>{const index=notes.length-1-reverseIndex;const row=document.createElement('div');row.className='note-item';const p=document.createElement('p');p.textContent=n.text;const del=document.createElement('button');del.textContent='DELETE';del.setAttribute('aria-label','Delete note');del.onclick=()=>{const a=getNotes();a.splice(index,1);saveNotes(a);toast('Memory deleted')};row.append(p,del);list.append(row)})
}
function addMessage(role,text){const box=document.createElement('div');box.className=`message ${role}`;const who=document.createElement('span');who.className='speaker';who.textContent=role==='user'?'YOU':'J.A.R.V.I.S.';const p=document.createElement('p');p.textContent=text;box.append(who,p);$('chatLog').append(box);$('chatLog').scrollTop=$('chatLog').scrollHeight}
function speak(text){if(!settings.speak||!('speechSynthesis'in window))return;window.speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(text);u.rate=.98;u.pitch=.9;window.speechSynthesis.speak(u)}
function say(text){addMessage('jarvis',text);speak(text)}
function openUrl(url){window.open(url,'_blank','noopener,noreferrer')}
function localCommand(text){
 const q=text.trim(),s=q.toLowerCase();
 if(/^(what time|time is it|tell me the time)/.test(s)){return `It is ${new Date().toLocaleTimeString([], {hour:'numeric',minute:'2-digit'})} on your device.`}
 if(s.includes('what can you do')||s==='help'){return 'I can chat through a configured AI endpoint, speak and listen when your browser supports it, tell the local time, open common websites, enter focus mode, and save or delete notes on this device.'}
 if(s.includes('focus mode')){document.body.classList.toggle('focus-mode');return document.body.classList.contains('focus-mode')?'Focus mode enabled. Distractions are hidden.':'Focus mode disabled.'}
 if(s.startsWith('remember that ')||s.startsWith('save note ')||s.startsWith('remember ')){const note=q.replace(/^(remember that|remember|save note)\s*/i,'').trim();if(note){const notes=getNotes();notes.push({text:note,createdAt:new Date().toISOString()});saveNotes(notes);return 'Saved to your local memory vault on this device.'}}
 if(s.includes('show my memories')||s.includes('show my notes')){showView('memory');const notes=getNotes();return notes.length?`You have ${notes.length} saved item${notes.length===1?'':'s'}. I opened the Memory Vault.`:'Your Memory Vault is empty. I opened it for you.'}
 if(s.includes('open youtube')){openUrl('https://www.youtube.com');return 'Opening YouTube in a new tab.'}
 if(s.includes('open google')||s.includes('search the web')){openUrl('https://www.google.com');return 'Opening Google in a new tab.'}
 if(s.includes('open gmail')||s.includes('open mail')){openUrl('https://mail.google.com');return 'Opening Gmail in a new tab.'}
 if(s.includes('open settings')){showView('settings');return 'System settings opened.'}
 return null;
}
async function askAI(text){
 const endpoint=(settings.endpoint||'').trim();
 if(!endpoint)return null;
 try{
  const response=await fetch(endpoint,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({message:text,history:[]})});
  if(!response.ok)throw new Error(`Server returned ${response.status}`);
  const data=await response.json();
  const answer=data.reply||data.text||data.response||data.message;
  if(typeof answer!=='string'||!answer.trim())throw new Error('Unexpected AI response format');
  $('connectionLabel').textContent='AI ENDPOINT · CONNECTED';return answer.trim();
 }catch(err){console.error(err);toast('AI connection failed — check endpoint');return `I couldn't reach your AI backend (${err.message}). Your local commands still work. Check the endpoint URL and backend logs.`}
}
async function handleCommand(text){
 const q=text.trim();if(!q)return;
 addMessage('user',q);$('promptInput').value='';
 const local=localCommand(q);if(local){say(local);return}
 const endpoint=(settings.endpoint||'').trim();
 if(endpoint){say('One moment.');const last=$('chatLog').lastElementChild;try{const answer=await askAI(q);if(answer){last.remove();say(answer)}else{last.remove();say('No answer received. Check your AI backend.')}}catch{last.remove();say('Something went wrong while contacting the AI backend.')}return}
 say('That needs the AI connection. Open System Settings and add your secure AI backend URL. I can still run local commands, open supported websites, tell the time, and manage your notes without it.');
}
function showView(name){document.querySelectorAll('.view').forEach(v=>v.classList.add('hidden'));$(`${name}View`).classList.remove('hidden');document.querySelectorAll('.tab').forEach(t=>t.classList.toggle('active',t.dataset.view===name))}
function startListening(){
 const SpeechRecognition=window.SpeechRecognition||window.webkitSpeechRecognition;
 if(!settings.voice){toast('Voice input is disabled in settings');return}
 if(!SpeechRecognition){toast('Speech recognition is not supported in this browser');$('voiceHint').textContent='Try a browser that supports speech recognition, and allow microphone access.';return}
 if(listening){recognition.stop();return}
 recognition=new SpeechRecognition();recognition.lang=navigator.language||'en-US';recognition.interimResults=false;recognition.maxAlternatives=1;
 recognition.onstart=()=>{listening=true;$('talkLabel').textContent='LISTENING…';$('statusText').textContent='VOICE INPUT ACTIVE'};
 recognition.onresult=(e)=>{const transcript=e.results[0][0].transcript;$('promptInput').value=transcript;handleCommand(transcript)};
 recognition.onerror=(e)=>toast(`Voice input: ${e.error}`);
 recognition.onend=()=>{listening=false;$('talkLabel').textContent='TALK TO JARVIS';$('statusText').textContent='SYSTEM READY'};
 try{recognition.start()}catch{toast('Voice input could not start')}
}
function applySettings(){
 $('speakToggle').checked=!!settings.speak;$('voiceToggle').checked=!!settings.voice;$('motionToggle').checked=!!settings.reducedMotion;$('endpointInput').value=settings.endpoint||'';
 document.body.classList.toggle('reduced-motion',!!settings.reducedMotion);
 $('connectionLabel').textContent=settings.endpoint?'AI ENDPOINT · CONFIGURED':'LOCAL MODE · AI NOT CONFIGURED';
}
document.querySelectorAll('.tab').forEach(t=>t.addEventListener('click',()=>showView(t.dataset.view)));
$('chatForm').addEventListener('submit',e=>{e.preventDefault();handleCommand($('promptInput').value)});
document.querySelectorAll('[data-command]').forEach(b=>b.addEventListener('click',()=>handleCommand(b.dataset.command)));
document.querySelectorAll('[data-url]').forEach(b=>b.addEventListener('click',()=>openUrl(b.dataset.url)));
$('talkBtn').addEventListener('click',startListening);
$('focusBtn').addEventListener('click',()=>{document.body.classList.toggle('focus-mode');toast(document.body.classList.contains('focus-mode')?'Focus mode enabled':'Focus mode disabled')});
$('newNoteBtn').addEventListener('click',()=>{showView('memory');$('noteInput').focus()});
$('noteForm').addEventListener('submit',e=>{e.preventDefault();const text=$('noteInput').value.trim();if(!text)return;const notes=getNotes();notes.push({text,createdAt:new Date().toISOString()});saveNotes(notes);$('noteInput').value='';toast('Memory saved on this device')});
$('clearMemoryBtn').addEventListener('click',()=>{if(confirm('Delete all locally saved JARVIS memories and notes from this browser?')){saveNotes([]);toast('Memory vault cleared')}});
$('saveSettingsBtn').addEventListener('click',()=>{settings={speak:$('speakToggle').checked,voice:$('voiceToggle').checked,reducedMotion:$('motionToggle').checked,endpoint:$('endpointInput').value.trim()};localStorage.setItem(KEYS.settings,JSON.stringify(settings));applySettings();toast('Settings saved on this device')});
$('testAiBtn').addEventListener('click',async()=>{settings.endpoint=$('endpointInput').value.trim();if(!settings.endpoint){toast('Add your AI backend URL first');return}toast('Testing AI connection…');const result=await askAI('Reply with exactly: JARVIS connection online.');say(result||'No response from backend.');});
window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();deferredInstall=e;$('installBtn').classList.remove('hidden')});
$('installBtn').addEventListener('click',async()=>{if(!deferredInstall){toast('Use your browser menu and choose Add to Home screen');return}deferredInstall.prompt();await deferredInstall.userChoice;deferredInstall=null;$('installBtn').classList.add('hidden')});
if('serviceWorker'in navigator && (location.protocol==='https:'||location.hostname==='localhost'))navigator.serviceWorker.register('./sw.js').catch(console.warn);
if(navigator.getBattery){navigator.getBattery().then(b=>{const update=()=>{$('batteryStat').textContent=`${Math.round(b.level*100)}%`; $('batteryHint').textContent=b.charging?'CHARGING':'BATTERY LEVEL';};update();b.addEventListener('levelchange',update);b.addEventListener('chargingchange',update)}).catch(()=>{$('batteryStat').textContent='UNAVAILABLE'})}else{$('batteryStat').textContent='UNAVAILABLE';$('batteryHint').textContent='Browser does not expose battery status'}
updateClock();setInterval(updateClock,1000);renderNotes();updateCounts();applySettings();
if(!('speechSynthesis'in window))$('voiceHint').textContent='Spoken replies are not supported in this browser.';
